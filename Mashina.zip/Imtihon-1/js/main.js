let activeDarklight = document.querySelector(".box__btn");


 activeDarklight.addEventListener("click", function(){
 document.body.classList.toggle("active-dark-light");
})