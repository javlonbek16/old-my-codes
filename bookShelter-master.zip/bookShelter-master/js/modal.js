const modal = document.querySelector(".backdrop");

export function showModal() {
  modal.classList.toggle("active");
}
