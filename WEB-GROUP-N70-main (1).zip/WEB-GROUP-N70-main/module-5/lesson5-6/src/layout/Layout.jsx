import React from 'react';
import "./style.scss";
const Layout = () => {
   return (
      <div>
         <h1>Layout</h1>
      </div>
   );
};

export default Layout;