import React from 'react';

const Private = () => {
   return (
      <div>
         {/* priavte routes  */}
      </div>
   );
};

export default Private;