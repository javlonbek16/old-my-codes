import React from 'react';
import "./style.scss";

const index = () => {
   return (
      <div>
         <h1>Sidebar</h1>
      </div>
   );
};

export default index;