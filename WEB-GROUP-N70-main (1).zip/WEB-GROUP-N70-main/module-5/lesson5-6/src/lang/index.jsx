export const language = {
  uz: {
    home: "Bosh sahifa",
    about: "Biz haqimizda",
    dark: "Tun",
    light: "Kun",
    copyright: "Qo'llab quvvatlanadi",
  },

  en: {
    home: "Home",
    about: "About",
    dark: "dark",
    light: "Light",
    copyright: "Powered by",
  },

  ru: {},
};

