import React from "react";
import "./style.scss";

const index = () => {
  return (
    <>
      <input type="text" className="form-control" />
    </>
  );
};

export default index;
