import React from 'react';
import "./style.scss";

const index = () => {
   return (
      <div className='card'>
         {/* card elements */}
      </div>
   );
};

export default index;