import React from 'react';
import "./style.scss";

const index = () => {
   return (
      <button>
         Button
      </button>
   );
};

export default index;