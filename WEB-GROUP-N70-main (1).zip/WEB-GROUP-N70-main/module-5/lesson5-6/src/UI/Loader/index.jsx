import React from 'react';
import "./style.scss";

const index = () => {
   return (
      <div>
         <span class="loader"></span>
      </div>
   );
};

export default index;