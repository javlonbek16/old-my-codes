export const Footer =()=>{
   return (
      <>
         <footer>
        <div className="container">
          <small>copyright by NAJOT TA'LIM . {new Date().getFullYear()} </small>
        </div>
      </footer>
      
      </>
   )
}