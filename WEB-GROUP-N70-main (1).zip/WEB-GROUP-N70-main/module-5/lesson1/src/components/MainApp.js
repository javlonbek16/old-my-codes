export default  function MainApp(){
   return (
      <>

      
       <main>
        <section>
          <div className="container">
            <div className="wrapper">
              <div className="card">card-1</div>
              <div className="card">card-2</div>
              <div className="card">card-3</div>
              <div className="card">card-4</div>
            </div>
          </div>
        </section>
      </main>
      
      
      
      </>
   )
}
