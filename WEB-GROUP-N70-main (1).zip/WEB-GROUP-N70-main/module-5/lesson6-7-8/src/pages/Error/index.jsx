import React from "react";

const index = () => {
  return (
    <div>
      <h1 className="text-center">NOT FOUND 404</h1>
    </div>
  );
};

export default index;
