import React from 'react';

const Tab1 = () => {
   return (
      <div className='card bg-info p-5 m-5 w-50 shadow-lg'>
         <h1>Tab 1</h1>
      </div>
   );
};

export default Tab1;