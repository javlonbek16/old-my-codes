import React from 'react';

const Tab2 = () => {
   return (
      <div className='card bg-warning p-5 m-5 w-50 shadow-lg'>
         <h1>Tab 2</h1>
      </div>
   );
};

export default Tab2;