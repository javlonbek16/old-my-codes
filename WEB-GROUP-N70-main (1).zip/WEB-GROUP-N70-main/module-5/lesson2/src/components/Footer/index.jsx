import "./style.scss";

const index = () => {
  return (
    <>
      <footer>
        <div className="container">
          <h5> { new Date().getFullYear() }</h5>
        </div>
      </footer>
    </>
  );
};

export default index;
