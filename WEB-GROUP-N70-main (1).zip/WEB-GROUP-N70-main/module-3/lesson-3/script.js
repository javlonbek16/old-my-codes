"use strict";

// console.log(12!=="12");


// 1222=="1222" // true
// 1222!="1222" // false

// 133==="133" // false
// 133!=="133" // true

// console.log(!false);

// let a=12;

// let n=String(a);

// let m=Number(n);

// let number="144";
// console.log(number);
// console.log(typeof("javascript"*4));

// let light = prompt('light=');

// if (light == 'red') {

//    console.log("STOP");

// } else if (light == 'yellow') {

//    console.log("ATTENTION");

// } else if (light == "green") {

//    console.log('GO');

// } else {
//    alert('NO WORKING')
// }

// let operator = +prompt('eneter operator code');  
// console.log(typeof(operator));

// switch (operator) {
//    case 93:
//       console.log('Ucell');
//       break;
//    case 94:
//       console.log('Ucell');
//       break;
//    case 99:
//       console.log('Uzmobile');
//       break;
//    case 97:
//       console.log('Uzmobi');
//       break;
//    case 90:
//       console.log('Belinee');
//       break;
//    case 91:
//       console.log('Belinee');
//       break;
//    case 95:
//       console.log('Uzmobile');
//       break;
//    default:
//       alert('NOT FOUND')
// }



//  true ? console.log('XA') : console.log("YO'Q")

// while , do while , for 

// ++ INCREMENT
// -- DECREMENT



// while(n<50){

//   n++
//   console.log(n);
//   console.log('salom');

// }


// let n = 40;

// do {
//    n++
//    console.log(n);
// } while (n < 10)



// for (let i=1; i<=40; i++){
//    console.log(i);
//    if(i==8)
//    break;

// }