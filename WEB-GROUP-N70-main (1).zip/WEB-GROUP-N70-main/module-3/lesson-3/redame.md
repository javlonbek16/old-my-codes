## Day 3
 - comparison operators (taqqoslash operatorlari)
 - type conversions
 - Conditional operator "if else"
- "switch" statement
 - Ternary operator

 - Loops: while and for ( while, do..while and for(..;..;..) ) 
 takrorlanish operatori 

 - Function and function types


