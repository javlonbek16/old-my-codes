"use strict";

// document.write(99**7)
// alert('salom javaScript');
// confirm('saytdan chiqasizmi ?')
// prompt('ismingiz nima?')
// document.getElementById('title').innerHTML="<p>Lorem ipsum</p>"
// document.getElementById('title').innerText="<p>Lorem ipsum</p>";
// document.getElementById('title').textContent="<p>Lorem ipsum</p>";
// console.log('javaScript lesson 2');
// console.log(33333*9);
// console.error('saytda xato bor');
// console.warn('warning')
// console.dir('lesson 2')

// + , - , * , / , % , **
// NaN = Not a Number
// JS data types

// PRIMATIVE va NON PRIMATIVE


// PRIMATIVE DATA TYPES

// NUMBER => 12 , 7 , 21, 0.0000003 , -122, , 1234.12432 , 0
// STRING => "12" , "javaScript" , 'personal hom page' , `lesson`;
// Boolean => true => 1 . false => 0
// Undefined
// null




// var fruit = 'apple';
//     fruit = "orange";
// var fruit = "limon";
// console.log(fruit);

//ES5
// let fruit = 'apple'
//     fruit="peach"
// // let fruit="ananas"
// console.log(fruit);

//ES6

// const fruit="apple";
//       // fruit="limons";
//       // const fruit="peach"

// console.log(fruit);


// {
//    const box="box";
//    // console.log(box);
// }

// box="comment"

// console.log(box);


// let a=12;
// let b=15;

//  a=a+b; 
//  a=a-b;
//  a=a*b;
//  a=a/b;
//  a=a%b;
//  a=a**b;

// a+=b; a=a+b => a+=b
// a-=b;
// a/=b;
// a%=b; 
// a**=b;


let a

//M-1

// let l=121;

// console.log(l/100+" metr");

//m-2

