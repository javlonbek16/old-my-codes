





// document.getElementById('text').textContent="5555*123";
// document.getElementById('box').innerHTML="<h1>"+5555*88+"</h1>";


// console.log( document.getElementById('matn').innerHTML);

//      document.write(5+25*10/100);
//      console.log('javaScript '+" lesson 1");
//    //   console.log(50066660*444);
//    //   console.error("saytda xatolik");
//    //   console.warn('internet tezligi past');

//    // alert('salom')
//    // confirm('saytdan chiqasizmi ?')
//    // prompt('ismingiz nima ?')


//  + , - , * , / , ** , %

// ES1
// ES3
// ES5
// ES6 2015

// console.log(2**8);
     


// Primative    ============  Non Primative

// 1. String  => "javaScript" , 'php personl home page' , `lesson 1`
// "1111" , 

// 2. Number => 11111 , 3444, 0.00000034 , -2333 , 232456789 

console.log(11>2);

//  Boolean = > true =1 , false=0

console.log(true+true);

print('salom')

