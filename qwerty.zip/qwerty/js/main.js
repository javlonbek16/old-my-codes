let modal = document.querySelector(".backdrop");
let showModalbtn = document.querySelector("#account");
let cancelbtn = document.querySelector("#sign-up");
let InputName = document.querySelector("#FullName");
let InputEmail = document.querySelector("#Email");
let InputPassword = document.querySelector("#Password");
let Userform = document.querySelector("#modal-form");

// function getToken() {
//   const form = new FormData();
//   form.append("username", FullName.value.trim());
//   form.append("email", Email.value.trim());
//   form.append("password", Password.value.trim());

//   fetch("https://task.samid.uz/v1/user/sign-in", {
//     method: "POST",
//     body: form,
//     headers: {
//       "Content-Type": "application/json",
//     },
//   })
//     .then((res) => {
//       return res.json();
//     })
//     .then((res) => {
//       console.log(res);
//       if (res.data?.token) {
//         localStorage.setItem("token", res.data.token);
//         location.replace("./second.html");
//       }
//     });
// }
// getToken();

function showModal() {
  modal.classList.toggle("active");
}

showModalbtn.addEventListener("click", showModal);
cancelbtn.addEventListener("submit", showModal);

function getToken() {
  const form = new FormData();
  form.append("username", "user123");
  form.append("password", "user123456");

  fetch("https://task.samid.uz/v1/user/sign-in", {
    method: "POST",
    body: form,
    headers: {
      AUTHORIZATION: "Bearer",
    },
  })
    .then((res) => {
      return res.json();
    })
    .then((res) => {
      console.log(res);
      localStorage.setItem("token", res.data.token);
    });
}
getToken();

// Userform.addEventListener("submit", (e) => {
//   e.preventDefault();
//   const form = new FormData();
//   form.append("username", InputName.value.trim());
//   form.append("email", InputEmail.value.trim());
//   form.append("password", InputPassword.value.trim());

//   function getTokenUp() {
//     fetch("https://task.samid.uz/v1/user/sign-up", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: form,
//     })
//       .then((res) => {
//         return res.json();
//       })
//       .then((res) => {
//         console.log(res);
//       });
//   }
// });
// getTokenUp();

Userform.addEventListener("submit", (e) => {
  e.preventDefault();
  const form = new FormData();
  form.append("username", InputName.value.trim());
  form.append("email", InputEmail.value.trim());
  form.append("password", InputPassword.value.trim());

  let options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      form,
    }),
  };

  fetch("https://task.samid.uz/v1/user/sign-up", options)
    .then((res) => res.json())
    .then((data) => {
      if (data?.token) {
        window.localStorage.setItem("token", data.token);
        window.location.replace("../second.html");
      }
    });
});
