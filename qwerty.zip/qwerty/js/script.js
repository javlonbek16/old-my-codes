//===   GETBOOKS START   ===//

let api = "https://books-13505-default-rtdb.firebaseio.com";
let books_content = document.querySelector("#books_orders");

function getAllBooks() {
  fetch(`${api}/books.json`, {
    method: "GET",
  })
    .then((res) => {
      if (!res.ok) throw res;
      return res.json();
    })
    .then((res) => {
      //   console.log(res);

      let arr2 = Object.keys(res).map((item) => {
        return {
          ...res[item],
          id: item,
        };
      });
      renderBooks(arr2);
    });
}

getAllBooks();
function renderBooks(arr) {
  let result = "";
  arr.forEach((element) => {
    result += `
    <div class="card" style="width: 18rem">
    <div class="bg-white p-3">
      <div class="p-2 bg-light">
        <img src="" class="p-3 card-img-top" alt="..." />
      </div>
    </div>
    <div class="card-body">
      <h5 class="card-title">${element.title} </h5>
      <p class="card-subtitle mb-2 text-muted">${element.author}</p>
      <p class="card-subtitle mb-2 text-muted">${element.publisheryear}</p>
      <div class="button-group d-flex gap-1 mb-1">
        <button type="button" class="w-50 btn btn-warning" id="buy"  value="${element.price}">
        ${element.price} so'm
        </button>
      </div>
    </div>
  </div>
  `;
  });
  books_content.innerHTML = result;
}

//===   GETBOOKS END   ===//

// cart.addEventListener("click", (e) => {
//   e.preventDefault();
// });

let modal = document.querySelector(".backdrop");
let showModalbtn = document.querySelector("#cart");
let cancelbtn = document.querySelector(".cancel-img");
let custom_modal = document.querySelector(".custom-modal");
let buyBook = document.querySelector("#buy");

function showModal() {
  modal.classList.toggle("active");
}

showModalbtn.addEventListener("click", showModal);
cancelbtn.addEventListener("click", showModal);
// custom_modal

//  get book title
buyBook.addEventListener("click", (e) => {
  let bookValue = buyBook.value.trim;
  custom_modal.innerHTML = bookValue;
});
