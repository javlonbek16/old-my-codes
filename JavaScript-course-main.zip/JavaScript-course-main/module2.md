
<img src="https://telegra.ph/file/f7c89c5eade284fd63ab3.png" width="800">
<h1 style="text-align:center"> Muhriddin Kohodiev 24 y.o  software engineer at</h1> 
<br>
<img src="https://najotedu.t8s.ru/Files/najotedu.t8s.ru/Photos/serwyrsu.ovh.png"  width="200" style="display:inline-block"> 
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Olcha.uz_-_logo.svg/2560px-Olcha.uz_-_logo.svg.png" width="200" style="display:inline-block;">

<hr>



<h1 style="text-align:center"> 

 JavaScript bo'yicha to'liq kurs reja</h1>

 <h2 style="text-align:center">module-2</h2>

<img src='https://camo.githubusercontent.com/bdd38b0c65d47c7cba62b60617adffedb3a48d1ac6e77501b990fffb1e52815c/68747470733a2f2f6d69726f2e6d656469756d2e636f6d2f6d61782f333230302f312a4f463078454d6b5742762d36397a766d4e73365244512e676966' alt='svg'>

<hr>

# Day 13
1. Mavzularni takrorlash (umummiy)
2. Object  , to built methods
  - Object.keys(testScore); // gives all keys
  - Object.values(testScore); // gives all values
  - Object.entries(testScore)
3. Javascript ‘this’ keyword (Context)

<hr>

# Day 14
1. **Movies app** (practice)
2. Find duplicates in an array using javaScript
3. **findElement** function
4. eventDelegation
5. dataset . . .
6. Template tag
7. RegExp() & ASCII code
  - https://regexr.com/
  - https://www.ascii-code.com/ 

 Javascript ‘this’ keyword (Context)